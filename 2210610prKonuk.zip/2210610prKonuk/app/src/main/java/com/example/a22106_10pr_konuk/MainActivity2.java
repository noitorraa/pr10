package com.example.a22106_10pr_konuk;

import static com.example.a22106_10pr_konuk.R.id.buttonBack;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity implements View.OnClickListener{
    Button sw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        sw = (Button) findViewById(R.id.buttonBack);
        sw.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent in = new Intent(this, MainActivity3.class);
        startActivity(in);
    }
}