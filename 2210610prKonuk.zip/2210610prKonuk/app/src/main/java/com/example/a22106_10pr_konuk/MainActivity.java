package com.example.a22106_10pr_konuk;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.a22106_10pr_konuk.databinding.ActivityMainBinding;

public class MainActivity extends Activity {

    private TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}